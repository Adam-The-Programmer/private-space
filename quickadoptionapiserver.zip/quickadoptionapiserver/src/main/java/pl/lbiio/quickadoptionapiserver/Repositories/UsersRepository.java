package pl.lbiio.quickadoptionapiserver.Repositories;

import pl.lbiio.quickadoptionapiserver.Models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.text.DecimalFormat;


@Repository
public class UsersRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public int insertUser(User user) {
        return jdbcTemplate.update(
                "INSERT INTO `user`(`UID`, `EmailAddress`, `Phone`, `Name`, `Surname`, `Country`, `City`, `Address`, `PostalCode`, `UserDescription`, `ProfileImage`, `MaxReliability`, `AcquiredReliability`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);",
                user.getUID(),
                user.getEmailAddress(),
                user.getPhone(),
                user.getName(),
                user.getSurname(),
                user.getCountry(),
                user.getCity(),
                user.getAddress(),
                user.getPostalCode(),
                user.getUserDescription(),
                user.getProfileImage(),
                user.getMaxReliability(),
                user.getAcquiredReliability()

        );
    }

    public int updateUser(User user, String UID) {
        return jdbcTemplate.update(
            "UPDATE `user` SET " +
            "`EmailAddress` = ?, " +
            "`Phone` = ?, " +
            "`Name` = ?, " +
            "`Surname` = ?, " +
            "`Country` = ?, " +
            "`City` = ?, " +
            "`Address` = ?, " +
            "`PostalCode` = ?, " +
            "`UserDescription` = ?, " +
            "`ProfileImage` = ?, " +
            "`MaxReliability` = ?, " +
            "`AcquiredReliability` = ? " +
            "WHERE `UID` = ?",
            user.getEmailAddress(),
            user.getPhone(),
            user.getName(),
            user.getSurname(),
            user.getCountry(),
            user.getCity(),
            user.getAddress(),
            user.getPostalCode(),
            user.getUserDescription(),
            user.getProfileImage(),
            user.getMaxReliability(),
            user.getAcquiredReliability(),
            UID
        );
    }


    public String getRateOfUser(String UID) {
        Integer acquiredReliability = jdbcTemplate.queryForObject(
            "SELECT AcquiredReliability FROM user WHERE UID = ?",
            Integer.class,
            UID
        );
    
        Integer maxReliability = jdbcTemplate.queryForObject(
            "SELECT MaxReliability FROM user WHERE UID = ?",
            Integer.class,
            UID
        );
    
        if (acquiredReliability != null && maxReliability != null && maxReliability != 0) {
            // Calculate the rate
            double rate = (acquiredReliability * 5.0) / maxReliability;
    
            // Round the rate to 2 decimal places
            DecimalFormat df = new DecimalFormat("#.##");
            String roundedRate = df.format(rate);
    
            return roundedRate;
        } else {
            // Handle cases where values are null or maxRealibility is 0
            return "N/A";
        }
    }

    public User getUser(String UID){
        return jdbcTemplate.queryForObject(
            "SELECT * FROM `user` WHERE `UID`=?;",
            BeanPropertyRowMapper.newInstance(User.class),
            UID
        );
    }

}
