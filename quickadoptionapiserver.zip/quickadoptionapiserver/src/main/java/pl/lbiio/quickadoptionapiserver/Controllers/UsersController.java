package pl.lbiio.quickadoptionapiserver.Controllers;

import pl.lbiio.quickadoptionapiserver.Models.*;
import pl.lbiio.quickadoptionapiserver.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class UsersController {
    
    @Autowired
    UsersRepository usersRepository;

    @PutMapping("/api/insertUser")
    public String insertUser(@RequestBody User user) {
        if(usersRepository.insertUser(user)==1){
            return "inserting sucesfull";
        }else{
            return "inserting failed";
        }
    }

    @PutMapping("/api/updateUser/{UID}")
    public String insertUser(@PathVariable("UID") String UID, @RequestBody User user) {
        if(usersRepository.updateUser(user, UID)==1){
            return "updating sucesfull";
        }else{
            return "updating failed";
        }
    }

    @GetMapping("/api/rateOfUser/{UID}")
    public String getRateOfUser(@PathVariable("UID") String UID) {
        return usersRepository.getRateOfUser(UID);
         
    }

    @GetMapping("/api/getUser/{UID}")
    public User getUser(@PathVariable("UID") String UID) {
        return usersRepository.getUser( UID);
    }


}
