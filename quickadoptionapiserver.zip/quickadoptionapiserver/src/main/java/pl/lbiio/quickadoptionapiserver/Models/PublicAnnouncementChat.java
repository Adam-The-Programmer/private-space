package pl.lbiio.quickadoptionapiserver.Models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PublicAnnouncementChat {
    private String ChatID;
    private Long AnnouncementID;
    private String OwnerID;
    private String Name;
    private String Surname;
    private String ProfileImage;
    private String LastMessageContent;
    private String LastMessageContentType;
    private Long lastMessageTimestamp;
    private String LastMessageAuthor;
    private Integer isAccepted;
}
