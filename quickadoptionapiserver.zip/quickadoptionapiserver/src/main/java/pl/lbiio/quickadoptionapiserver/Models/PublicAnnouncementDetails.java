package pl.lbiio.quickadoptionapiserver.Models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PublicAnnouncementDetails {
    private Long AnnouncementId;
    private String OwnerID;
    private String DateRange;
    private String Food;
    private String AnimalImage;
    private String AnimalDescription;
    private String OwnerDescription;
    private String OwnerImage;
    private String Country;
    private String City;
}
