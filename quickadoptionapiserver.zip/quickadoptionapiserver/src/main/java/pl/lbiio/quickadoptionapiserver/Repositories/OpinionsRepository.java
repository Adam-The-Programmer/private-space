package pl.lbiio.quickadoptionapiserver.Repositories;



import pl.lbiio.quickadoptionapiserver.Models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import java.sql.PreparedStatement;



@Repository
public class OpinionsRepository {
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    public int insertOpinion(OpinionToInsertDTO opinionToInsertDTO) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
    
        int i = jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO `opinion`(`AuthorID`, `Content`, `Timestamp`, `RateStars`) VALUES (?,?,?,?)",
                new String[] { "OpinionID" }
            );
            ps.setString(1, opinionToInsertDTO.getAuthorID());
            ps.setString(2, opinionToInsertDTO.getContent());
            ps.setLong(3, System.currentTimeMillis());
            ps.setInt(4, opinionToInsertDTO.getRate());
            return ps;
        }, keyHolder);
    
        int opinionID = keyHolder.getKey().intValue();
    
        int j = jdbcTemplate.update(
            "INSERT INTO `opinionstousers`(`OpinionID`, `ReceiverID`) VALUES (?,?)",
            opinionID,
            opinionToInsertDTO.getReceiverID()
        );

        int k = jdbcTemplate.update(
            "UPDATE `user` SET `MaxRealibility`=`MaxRealibility`+5, `AcquiredRealibility`=`AcquiredRealibility`+? WHERE `UID`=?;",
            opinionToInsertDTO.getRate(),
            opinionToInsertDTO.getReceiverID()
        );

        return i+j+k; 
    }

    public List<Opinion> getOpinions(String ReceiverID) {
        return jdbcTemplate.query(
                "SELECT `opinion`.`OpinionID`, `user`.`Name` AS `AuthorName`, `user`.`Surname` AS `AuthorSurname`, `user`.`ProfileImage` AS `AuthorImage`, `Content`, `Timestamp`, `RateStars` FROM `opinion` JOIN `opinionstousers` ON `opinionstousers`.`OpinionID` = `opinion`.`OpinionID` JOIN `user` ON `user`.`UID` = `opinion`.`AuthorID` WHERE `opinionstousers`.`ReceiverID`=?;",
                BeanPropertyRowMapper.newInstance(Opinion.class),
                ReceiverID
        );
    }

}
