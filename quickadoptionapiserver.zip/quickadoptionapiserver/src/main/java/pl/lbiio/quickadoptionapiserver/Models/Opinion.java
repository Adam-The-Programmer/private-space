package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Opinion {
    private Long OpinionID;
    private String AuthorName;
    private String AuthorSurname;
    private String AuthorImage;
    private String Content;
    private String Timestamp;
    private Integer RateStars;
}
