package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ApplicationForAdoptionDTO {
    private Long announcementID;
    private String chatID;
    private String ownerID;
    private String keeperID;
    private String lastMessageContent;
    private String lastMessageContentType;
    private String lastMessageAuthor;
}
