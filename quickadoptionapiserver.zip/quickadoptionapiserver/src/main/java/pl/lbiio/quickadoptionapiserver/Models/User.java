package pl.lbiio.quickadoptionapiserver.Models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class User {
    private String UID;
    private String emailAddress;
    private String phone;
    private String name;
    private String surname;
    private String country;
    private String city;
    private String address;
    private String postalCode;
    private String userDescription;
    private String profileImage;
    private String maxReliability;
    private String acquiredReliability;
}
