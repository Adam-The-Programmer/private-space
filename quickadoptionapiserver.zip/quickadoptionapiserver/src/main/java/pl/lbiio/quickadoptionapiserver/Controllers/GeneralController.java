package pl.lbiio.quickadoptionapiserver.Controllers;

import org.springframework.web.bind.annotation.*;

@RestController
public class GeneralController {
    
    @GetMapping("/api/test")
    public String testingQuery() {
        return "Testing... Successful";
    }
}
