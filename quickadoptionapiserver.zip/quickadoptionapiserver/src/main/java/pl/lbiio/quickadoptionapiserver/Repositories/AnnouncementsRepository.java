package pl.lbiio.quickadoptionapiserver.Repositories;

import pl.lbiio.quickadoptionapiserver.Models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public class AnnouncementsRepository {
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<OwnAnnouncementListItem> getAllOwnAnnouncementListItems(String UID) {
        return jdbcTemplate.query(
                "SELECT `announcement`.`AnnouncementID`, `AnimalName`, `Species`, `Breed`, `DateRange`, `AnimalImage`, `HasNewOffer`, COUNT(`ChatID`) as `NumberOfOffers` FROM `announcement`, `announcementstochats` WHERE `ownerID`=? AND `announcement`.`AnnouncementID`=`announcementstochats`.`AnnouncementID`;",
                BeanPropertyRowMapper.newInstance(OwnAnnouncementListItem.class),
                UID
        );
    }

    public OwnAnnouncement getParticularOwnAnnouncement(Long AnnouncementID) {
        return jdbcTemplate.queryForObject(
                "SELECT `announcement`.`AnnouncementID`, `AnimalName`, `Species`, `Breed`, `DateRange`, `Food`, `AnimalImage`, `AnimalDescription` FROM `announcement` WHERE `AnnouncementID`=?;",
                BeanPropertyRowMapper.newInstance(OwnAnnouncement.class),
                AnnouncementID
        );
    }

    public int deleteAnnouncement(Long AnnouncementID) {

        String ChatID = jdbcTemplate.queryForObject(
            "SELECT `ChatID` FROM `announcementstochats` WHERE `AnnouncementID`=?",
            String.class,
            AnnouncementID
        );

        int i = jdbcTemplate.update(
            "DELETE FROM `userstochats` WHERE `ChatID`=?",
            ChatID
        );

        int j = jdbcTemplate.update(
            "DELETE FROM `announcementstochats` WHERE `AnnouncementID`=?",
            AnnouncementID
        );

        int k = jdbcTemplate.update(
            "DELETE FROM `announcement` WHERE `AnnouncementID`=?;",
            AnnouncementID
        );
        
        return i+j+k;
       
    }

    public int updateAnnouncement(OwnAnnouncement ownAnnouncement) {
        return jdbcTemplate.update(
            "UPDATE `announcement` SET `AnimalName`=?, `Species`=?, `Breed`=?, `DateRange`=?, `Food`=?, `AnimalImage`=?, `AnimalDescription`=? WHERE `AnnouncementID`=?;",
            ownAnnouncement.getAnimalName(),
            ownAnnouncement.getSpecies(),
            ownAnnouncement.getBreed(),
            ownAnnouncement.getDateRange(),
            ownAnnouncement.getFood(),
            ownAnnouncement.getAnimalImage(),
            ownAnnouncement.getAnimalDescription(),
            ownAnnouncement.getAnnouncementID()
        );
    }

    public int addAnnouncement(OwnAnnouncement ownAnnouncement, String UID) {
        return jdbcTemplate.update(
            "INSERT INTO `announcement` (`AnimalName`, `Species`, `Breed`, `DateRange`, `Food`, `AnimalImage`, `AnimalDescription`, `OwnerID`, `AssignedKeeperID`, `HasNewOffer`) VALUES (?,?,?,?,?,?,?,?,?,?)",
            ownAnnouncement.getAnimalName(),
            ownAnnouncement.getSpecies(),
            ownAnnouncement.getBreed(),
            ownAnnouncement.getDateRange(),
            ownAnnouncement.getFood(),
            ownAnnouncement.getAnimalImage(),
            ownAnnouncement.getAnimalDescription(),
            UID,
            UID,
            false
        );
    }

    public int setAnnouncementHaveUnreadMessage(Long AnnouncementID) {
        return jdbcTemplate.update(
            "UPDATE `announcement` SET `HasNewOffer`=1 WHERE `AnnouncementID`=?",
            AnnouncementID
        );
    }

    public int setAnnouncementDontHaveUnreadMessage(Long AnnouncementID) {
        return jdbcTemplate.update(
            "UPDATE `announcement` SET `HasNewOffer`=0 WHERE `AnnouncementID`=?",
            AnnouncementID
        );
    }

    public int assignKeeperToAnnouncement(Long AnnouncementID, String KeeperUID) {
        return jdbcTemplate.update(
            "UPDATE `announcement` SET `AssignedKeeperID`=? WHERE `AnnouncementID`=?",
            KeeperUID,
            AnnouncementID
        );
    }

    public List<PublicAnnouncementListItem> getAllPublicAnnouncementListItems(String Country, String City, String DateRange, String UID) {
        String from = DateRange.split("-")[0];
        String to = DateRange.split("-")[1];
        return jdbcTemplate.query(
                "SELECT `AnnouncementID`, `AnimalName`, `Species`, `Breed`, `DateRange`, `AnimalImage`, `Country`, `City` FROM `announcement` JOIN `user` ON `announcement`.`OwnerID`=`user`.`UID` WHERE `OwnerID` = `AssignedKeeperID` AND `user`.`UID` = `announcement`.`OwnerID` and `Country`=? and `City`=? and OwnerID!=?; and STR_TO_DATE(SUBSTRING_INDEX(`DateRange`, '-', 1), '%d.%m.%Y') BETWEEN STR_TO_DATE(?, '%d.%m.%Y') AND STR_TO_DATE(?, '%d.%m.%Y') AND STR_TO_DATE(SUBSTRING_INDEX(`DateRange`, '-', -1), '%d.%m.%Y') BETWEEN STR_TO_DATE(?, '%d.%m.%Y') AND  STR_TO_DATE(?, '%d.%m.%Y');",
                BeanPropertyRowMapper.newInstance(PublicAnnouncementListItem.class),
                Country,
                City,
                UID,
                from,
                to,
                from,
                to
        );
    }

    public PublicAnnouncementDetails getParticularPublicAnnouncement(Long AnnouncementID) {
        return jdbcTemplate.queryForObject(
                "SELECT `AnnouncementID`, `OwnerID`, `DateRange`, `Food`, `AnimalImage`, `AnimalDescription`, `user`.`UserDescription` as `OwnerDescription`, `user`.`ProfileImage` as `OwnerImage`, `user`.`Country` as `Country`, `user`.`City` as `City` FROM `announcement`, `user` WHERE `announcement`.`OwnerID`=`user`.`UID` AND `announcement`.`AnnouncementID`=?;",
                BeanPropertyRowMapper.newInstance(PublicAnnouncementDetails.class),
                AnnouncementID
        );
    }

    public int applyForAdoption(ApplicationForAdoptionDTO applicationForAdoptionDTO) {
        int k = jdbcTemplate.update(
            "INSERT INTO `announcementstochats`(`ChatID`, `AnnouncementID`, `LastMessageContent`, `LastMessageContentType`, `LastMessageTimestamp`, `LastMessageAuthor`, `IsChatAccepted`) VALUES (?,?,?,?,?,?,?)",
            applicationForAdoptionDTO.getChatID(),
            applicationForAdoptionDTO.getAnnouncementID(),
            applicationForAdoptionDTO.getLastMessageContent(),
            applicationForAdoptionDTO.getLastMessageContentType(),
            System.currentTimeMillis(),
            applicationForAdoptionDTO.getLastMessageAuthor(),
            -1
        );
       
        int i = jdbcTemplate.update(
            "INSERT INTO `userstochats` (`ChatID`, `UID`) VALUES (?,?)",
            applicationForAdoptionDTO.getChatID(),
            applicationForAdoptionDTO.getOwnerID()
        );
        int j = jdbcTemplate.update(
            "INSERT INTO `userstochats` (`ChatID`, `UID`) VALUES (?,?)",
            applicationForAdoptionDTO.getChatID(),
            applicationForAdoptionDTO.getKeeperID()
        );
        
        return i+j+k;
    }





}
