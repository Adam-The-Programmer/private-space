package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OpinionToInsertDTO {
    private String AuthorID;
    private String ReceiverID; 
    private int Rate;
    private String Content;
}
