package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class LastMessageDTO {
   private String Message;
   private String MessageType;
   private String UID;
}
