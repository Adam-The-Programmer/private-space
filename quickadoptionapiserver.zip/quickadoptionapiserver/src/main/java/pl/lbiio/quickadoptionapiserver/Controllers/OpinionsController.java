package pl.lbiio.quickadoptionapiserver.Controllers;

import pl.lbiio.quickadoptionapiserver.Models.*;
import pl.lbiio.quickadoptionapiserver.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OpinionsController {
    
    @Autowired
    OpinionsRepository opinionsRepository;

    @PutMapping("/api/insertOpinion")
    public String insertOpinion(@RequestBody OpinionToInsertDTO opinionToInsertDTO) {
        if(opinionsRepository.insertOpinion(opinionToInsertDTO)==3){
            return "inserting sucesfull";
        }else{
            return "inserting failed";
        }
    }

    @GetMapping("/api/opinions/{ReceiverID}")
    public List<Opinion> getOpinions(@PathVariable("ReceiverID") String ReceiverID) {
        return opinionsRepository.getOpinions(ReceiverID);
    }
}
