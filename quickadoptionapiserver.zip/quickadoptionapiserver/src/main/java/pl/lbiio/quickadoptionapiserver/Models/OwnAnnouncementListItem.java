package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OwnAnnouncementListItem {
    private Long AnnouncementID;
    private String AnimalName;
    private String Species;
    private String Breed;
    private String DateRange;
    private String AnimalImage;
    private Boolean HasNewOffer;
    private Integer NumberOfOffers;
}
