package pl.lbiio.quickadoptionapiserver.Controllers;


import pl.lbiio.quickadoptionapiserver.Models.*;
import pl.lbiio.quickadoptionapiserver.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AnnouncementsController {

    @Autowired
    AnnouncementsRepository announcementsRepository;

    @GetMapping("/api/allOwnAnnouncementList/{UID}")
    public List<OwnAnnouncementListItem> getAllOwnAnnouncementListItems(@PathVariable("UID") String UID) {
        return announcementsRepository.getAllOwnAnnouncementListItems(UID);
    }

    @GetMapping("/api/particularOwnAnnouncement/{AnnouncementID}")
    public OwnAnnouncement getParticularOwnAnnouncement(@PathVariable("AnnouncementID") Long AnnouncementID) {
        return announcementsRepository.getParticularOwnAnnouncement(AnnouncementID);
    }

    @DeleteMapping("/api/deleteAnnouncement/{AnnouncementID}")
    public String deleteAnnouncement(@PathVariable("AnnouncementID") Long AnnouncementID) {
        int rowsDel = announcementsRepository.deleteAnnouncement(AnnouncementID);
        if( rowsDel>0){
            return "Deleting successful";
        }
        else{
            return "Deleting failed";
        }
    }

    @PutMapping("/api/updateAnnouncement")
    public String updateAnnouncement(@RequestBody OwnAnnouncement ownAnnouncement) {
        int i = announcementsRepository.updateAnnouncement(ownAnnouncement);
        if(i==1){
            return "Updating succesful";
        }
        else{
            return "Updating failed";
        }
    }

    @PutMapping("/api/addAnnouncement/{UID}")
    public String addAnnouncement(@PathVariable("UID") String UID, @RequestBody OwnAnnouncement ownAnnouncement) {
        if(announcementsRepository.addAnnouncement(ownAnnouncement, UID)==1){
            return "Inserting succesfull";
        }
        else{
            return "Inserting failed";
        }
    }

    @PutMapping("/api/setAnnouncementHaveUnreadMessage/{AnnouncementID}")
    public String setAnnouncementHaveUnreadMessage(@PathVariable("AnnouncementID") Long AnnouncementID) {
        if(announcementsRepository.setAnnouncementHaveUnreadMessage(AnnouncementID)==1){
            return "updating succesfull";
        }
        else{
            return "updating failed";
        }
    }
    @PutMapping("/api/setAnnouncementDontHaveUnreadMessage/{AnnouncementID}")
    public String setAnnouncementDontHaveUnreadMessage(@PathVariable("AnnouncementID") Long AnnouncementID) {
        if(announcementsRepository.setAnnouncementDontHaveUnreadMessage(AnnouncementID)==1){
            return "updating succesfull";
        }
        else{
            return "updating failed";
        }
    }

    @PutMapping("/api/assignKeeperToAnnouncement/{UID}/{AnnouncementID}")
    public String assignKeeperToAnnouncement(@PathVariable("UID") String UID, @PathVariable("AnnouncementID") Long AnnouncementID) {
        if(announcementsRepository.assignKeeperToAnnouncement(AnnouncementID, UID)==1){
            return "Inserting succesfull";
        }
        else{
            return "Inserting failed";
        }
    }

    @GetMapping("/api/getAllPublicAnnouncementListItems/{Country}/{City}/{DateRange}/{UID}")
    public List<PublicAnnouncementListItem> getAllPublicAnnouncementListItems(@PathVariable("Country") String Country, @PathVariable("City") String City, @PathVariable("DateRange") String DateRange, @PathVariable("UID") String UID) {
       return announcementsRepository.getAllPublicAnnouncementListItems(Country, City, DateRange, UID);
    }

    @GetMapping("/api/getParticularPublicAnnouncement/{AnnouncementID}")
    public PublicAnnouncementDetails getParticularPublicAnnouncement(@PathVariable("AnnouncementID") Long AnnouncementID) {
       return announcementsRepository.getParticularPublicAnnouncement(AnnouncementID);
        
    }

    @PutMapping("/api/applyForAdoption")
    public String applyForAdoption(
        @RequestBody ApplicationForAdoptionDTO applicationForAdoptionDTO) 
             {
       if(announcementsRepository.applyForAdoption(applicationForAdoptionDTO)==3){
        return "update succesfull";
       }
       else{
        return "update failed";
       }
        
    }
    
}
