package pl.lbiio.quickadoptionapiserver.Repositories;

import pl.lbiio.quickadoptionapiserver.Models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ChatsRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<OwnAnnouncementChat> getOwnChatsForAnnouncement(String UID, Long AnnouncementID) {
        return jdbcTemplate.query(
                "SELECT announcementstochats.ChatID AS ChatID, userstochats.UID AS PotentialKeeperID, user.Name AS Name, user.Surname AS Surname, user.ProfileImage AS ProfileImage, announcementstochats.LastMessageContent, announcementstochats.LastMessageContentType, announcementstochats.LastMessageTimestamp, announcementstochats.LastMessageAuthor, announcementstochats.IsAccepted FROM announcementstochats JOIN userstochats ON announcementstochats.ChatID = userstochats.ChatID JOIN user ON userstochats.UID = user.UID JOIN announcement ON announcementstochats.AnnouncementID = announcement.AnnouncementID WHERE userstochats.UID != ? AND user.UID != ? AND announcement.OwnerID = ? AND announcement.AnnouncementID = ? GROUP BY announcementstochats.ChatID;",
                BeanPropertyRowMapper.newInstance(OwnAnnouncementChat.class),
                UID,
                UID,
                UID,
                AnnouncementID

        );
    }

    public List<PublicAnnouncementChat> getPublicChatsForUser(String UID) {
        return jdbcTemplate.query(
                "SELECT announcementstochats.ChatID AS ChatID, announcementstochats.AnnouncementID AS AnnouncementID, announcement.OwnerID AS OwnerID, user.Name AS Name, user.Surname AS Surname, user.ProfileImage AS ProfileImage, announcementstochats.LastMessageContent, announcementstochats.LastMessageContentType, announcementstochats.LastMessageTimestamp, announcementstochats.LastMessageAuthor, announcementstochats.IsAccepted FROM announcementstochats JOIN announcement ON announcementstochats.AnnouncementID = announcement.AnnouncementID JOIN userstochats ON announcementstochats.ChatID = userstochats.ChatID JOIN user ON userstochats.UID = user.UID WHERE userstochats.UID = ? and announcement.OwnerID != ? GROUP BY announcementstochats.ChatID;",
                BeanPropertyRowMapper.newInstance(PublicAnnouncementChat.class),
                UID,
                UID
        );
    }


    public int setLastMessageForChat(LastMessageDTO lastMessageDTO, String ChatID) {
        return jdbcTemplate.update(
                "UPDATE `announcementstochats` SET `LastMessageContent`=?, `LastMessageContentType`=?, `LastMessageTimestamp`=?, `LastMessageAuthor`=? WHERE `ChatID`=?",
                lastMessageDTO.getMessage(),
                lastMessageDTO.getMessageType(),
                System.currentTimeMillis(),
                lastMessageDTO.getUID(),
                ChatID
        );
    }

    public int makeChatAccepted(Long AnnouncementID, String ChatID){
        int i = jdbcTemplate.update(
            "UPDATE `announcementstochats` SET `IsChatAccepted`=0 WHERE `AnnouncementId`=?",
            AnnouncementID
        );

        int j = jdbcTemplate.update(
            "UPDATE `announcementstochats` SET `IsChatAccepted`=1 WHERE `ChatID`=?",
            ChatID
        );

        return i+j;
    }
}
