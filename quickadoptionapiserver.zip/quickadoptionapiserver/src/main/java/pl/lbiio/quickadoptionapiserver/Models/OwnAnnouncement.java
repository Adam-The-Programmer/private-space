package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OwnAnnouncement {
    private Long AnnouncementID;
    private String AnimalName;
    private String Species;
    private String Breed;
    private String DateRange;
    private String Food;
    private String AnimalImage;
    private String AnimalDescription;
}
