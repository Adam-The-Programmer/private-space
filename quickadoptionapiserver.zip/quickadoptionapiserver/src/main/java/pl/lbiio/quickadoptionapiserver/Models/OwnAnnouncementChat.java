package pl.lbiio.quickadoptionapiserver.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OwnAnnouncementChat {
    private String ChatID;
    private String PotentialKeeperID;
    private String Name;
    private String Surname;
    private String ProfileImage;
    private String LastMessageContent;
    private String LastMessageContentType;
    private String LastMessageTimestamp;
    private String LastMessageAuthor;
    private Boolean IsAccepted;
}
