package pl.lbiio.quickadoptionapiserver.Controllers;

import pl.lbiio.quickadoptionapiserver.Models.*;
import pl.lbiio.quickadoptionapiserver.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ChatsController {
    
    @Autowired
    ChatsRepository chatsRepository;

    @GetMapping("/api/ownChatsForAnnouncement/{UID}/{AnnouncementID}")
    public List<OwnAnnouncementChat> getOwnChatsForAnnouncement(@PathVariable("UID") String UID, @PathVariable("AnnouncementID") Long AnnouncementID) {
        return chatsRepository.getOwnChatsForAnnouncement(UID, AnnouncementID);
    }

    @GetMapping("/api/publicChatsForUser/{UID}")
    public List<PublicAnnouncementChat> getPublicChatsForUser(@PathVariable("UID") String UID) {
        return chatsRepository.getPublicChatsForUser(UID);
    }

    @PutMapping("/api/lastMessageForChat/{ChatID}")
    public String setLastMessageForChat(@PathVariable("ChatID") String ChatID, @RequestBody LastMessageDTO lastMessageDTO) {
        if(chatsRepository.setLastMessageForChat(lastMessageDTO, ChatID)==1){
            return "updating succesfull";
        } else{
            return "updating failure";
        }
    }

    @PutMapping("/api/makeChatAccepted/{AnnouncementID}/{ChatID}")
    public String makeChatAccepted(@PathVariable("AnnouncementID") Long AnnouncementID, @PathVariable("ChatID") String ChatID) {
        if(chatsRepository.makeChatAccepted(AnnouncementID, ChatID)>0){
            return "updating succesfull";
        } else{
            return "updating failure";
        }
    }

}
