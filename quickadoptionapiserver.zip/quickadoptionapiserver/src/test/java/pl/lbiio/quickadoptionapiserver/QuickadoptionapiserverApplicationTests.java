package pl.lbiio.quickadoptionapiserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickadoptionapiserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
